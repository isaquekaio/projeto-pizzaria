﻿using Modelo;
using Persistencia;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Negocio
{
    class NPedido
    {
        public List<MPedido> Select()
        {
            PPedido p = new PPedido();
            return p.Select();
        }
        public void Insert(MPedido c)
        {
            /* Validação do Id
            PPedido p = new PPedido();
            List<MPedido> l = p.Select();
            if (l.Where(x => x.Id == c.Id).Count() > 0)
                throw new ArgumentOutOfRangeException();*/
            p.Insert(c);
        }
        public void Update(MPedido c)
        {
            PPedido p = new PPedido();
            p.Update(c);
        }
        public void Delete(MPedido c)
        {
            PPedido p = new PPedido();
            p.Delete(c);
        }
    }
}
