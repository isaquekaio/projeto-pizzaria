﻿using Modelo;
using Persistencia;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Persistencia
{
    class NCliente
    {
        public List<MCliente> Select()
        {
            PCliente p = new PCliente();
            return p.Select();
        }
        public void Insert(MCliente c)
        {
            // Validação do Nome
            if (c.Nome == "") throw new ArgumentOutOfRangeException();
            // Validação do Id
            PCliente p = new PCliente();
            List<MCliente> l = p.Select();
            if (l.Where(x => x.Id == c.Id).Count() > 0)
                throw new ArgumentOutOfRangeException();
            p.Insert(c);
        }
        public void Update(MCliente c)
        {
            // Validação
            if (c.Nome == "") throw new ArgumentOutOfRangeException();
            PCliente p = new PCliente();
            p.Update(c);
        }
        public void Delete(MCliente c)
        {
            PCliente p = new PCliente();
            p.Delete(c);
        }
    }
}
