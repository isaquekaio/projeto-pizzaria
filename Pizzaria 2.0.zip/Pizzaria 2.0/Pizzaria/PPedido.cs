﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using Modelo;

namespace Persistencia
{
    class PPedido
    {
        private string arquivo = "c:\\temp\\pedido.xml";
        private List<MPedido> Abrir()
        {
            XmlSerializer xml = new XmlSerializer(typeof(List<MPedido>));
            StreamReader f = new StreamReader(arquivo, Encoding.Default);
            List<MPedido> l = (List<MPedido>)xml.Deserialize(f);
            f.Close();
            return l;
        }
        private void Salvar(List<MPedido> l)
        {
            XmlSerializer xml = new XmlSerializer(typeof(List<MPedido>));
            StreamWriter f = new StreamWriter(arquivo, false, Encoding.Default);
            xml.Serialize(f, l);
            f.Close();
        }
        public List<MPedido> Select()
        {
            try
            {
                return Abrir();
            }
            catch
            {
            }
            return new List<MPedido>();
        }
        public void Insert(MPedido c)
        {
            List<MPedido> l = null;
            try
            {
                l = Abrir();
            }
            catch
            {
                l = new List<MPedido>();
            }
            l.Add(c);
            Salvar(l);
        }
        public void Update(MPedido c)
        {
            List<MPedido> l = Select();
            IEnumerable<MPedido> lcont = l.Where(x => x.Id == c.Id);
            if (lcont.Count() > 0)
            {
                MPedido lc = lcont.First();
                lc.Id = c.Id;
                lc.Nome = c.Nome;
           
                Salvar(l);
            }
            /*for (int i = 0; i < l.Count; i++)
                if (l[i].Id == c.Id)
                {

                }*/
        }
        public void Delete(MPedido c)
        {
            List<MPedido> l = Select();
            IEnumerable<MPedido> lcont = l.Where(x => x.Id == c.Id);
            if (lcont.Count() > 0)
            {
                l.Remove(lcont.First());
                Salvar(l);
            }
        }
    }
}
