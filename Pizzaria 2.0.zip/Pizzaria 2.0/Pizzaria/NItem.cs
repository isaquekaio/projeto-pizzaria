﻿using Modelo;
using Persistencia;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Negocio
{
    class NItem
    {
        public List<MItem> Select()
        {
            PItem p = new PItem();
            return p.Select();
        }
        public void Insert(MItem c)
        {
            // Validação do Nome
            if (c.Nome == "") throw new ArgumentOutOfRangeException();
            // Validação do Id
            PItem p = new PItem();
            List<MItem> l = p.Select();
            if (l.Where(x => x.Id == c.Id).Count() > 0)
                throw new ArgumentOutOfRangeException();
            p.Insert(c);
        }
        public void Update(MItem c)
        {
            // Validação
            if (c.Nome == "") throw new ArgumentOutOfRangeException();
            PItem p = new PItem();
            p.Update(c);
        }
        public void Delete(MItem c)
        {
            PItem p = new PItem();
            p.Delete(c);
        }
    }
}
