﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using Modelo;

namespace Persistencia
{
    class PCliente
    {
        private string arquivo = "c:\\temp\\cliente.xml";
        private List<MCliente> Abrir()
        {
            XmlSerializer xml = new XmlSerializer(typeof(List<MCliente>));
            StreamReader f = new StreamReader(arquivo, Encoding.Default);
            List<MCliente> l = (List<MCliente>)xml.Deserialize(f);
            f.Close();
            return l;
        }
        private void Salvar(List<MCliente> l)
        {
            XmlSerializer xml = new XmlSerializer(typeof(List<MCliente>));
            StreamWriter f = new StreamWriter(arquivo, false, Encoding.Default);
            xml.Serialize(f, l);
            f.Close();
        }
        public List<MCliente> Select()
        {
            try
            {
                return Abrir();
            }
            catch
            {
            }
            return new List<MCliente>();
        }
        public void Insert(MCliente c)
        {
            List<MCliente> l = null;
            try
            {
                l = Abrir();
            }
            catch
            {
                l = new List<MCliente>();
            }
            l.Add(c);
            Salvar(l);
        }
        public void Update(MCliente c)
        {
            List<MCliente> l = Select();
            IEnumerable<MCliente> lcont = l.Where(x => x.Id == c.Id);
            if (lcont.Count() > 0)
            {
                MCliente lc = lcont.First();
                lc.Id = c.Id;
                lc.Nome = c.Nome;
                lc.Fone = c.Fone;
                lc.Endereco = c.Endereco;

                Salvar(l);
            }
            /*for (int i = 0; i < l.Count; i++)
                if (l[i].Id == c.Id)
                {

                }*/
        }
        public void Delete(MCliente c)
        {
            List<MCliente> l = Select();
            IEnumerable<MCliente> lcont = l.Where(x => x.Id == c.Id);
            if (lcont.Count() > 0)
            {
                l.Remove(lcont.First());
                Salvar(l);
            }
        }
    }
}
