﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Linq;
using System.Xml.Serialization;
using Modelo;

namespace Persistencia
{
    class PFuncionario
    {
        private string arquivo = "c:\\temp\\funcionario.xml";
        private List<MFuncionario> Abrir()
        {
            XmlSerializer xml = new XmlSerializer(typeof(List<MFuncionario>));
            StreamReader f = new StreamReader(arquivo, Encoding.Default);
            List<MFuncionario> l = (List<MFuncionario>)xml.Deserialize(f);
            f.Close();
            return l;
        }
        private void Salvar(List<MFuncionario> l)
        {
            XmlSerializer xml = new XmlSerializer(typeof(List<MFuncionario>));
            StreamWriter f = new StreamWriter(arquivo, false, Encoding.Default);
            xml.Serialize(f, l);
            f.Close();
        }
        public List<MFuncionario> Select()
        {
            try
            {
                return Abrir();
            }
            catch
            {
            }
            return new List<MFuncionario>();
        }
        public void Insert(MPedido c)
        {
            List<MFuncionario> l = null;
            try
            {
                l = Abrir();
            }
            catch
            {
                l = new List<MFuncionario>();
            }
            l.Add(c);
            Salvar(l);
        }
        public void Update(MFuncionario c)
        {
            List<MFuncionario> l = Select();
            IEnumerable<MFuncionario> lcont = l.Where(x => x.Id == c.Id);
            if (lcont.Count() > 0)
            {
                MFuncionario lc = lcont.First();
                lc.Id = c.Id;
                lc.Nome = c.Nome;
                lc.Senha = c.Senha;
                
                Salvar(l);
            }
            /*for (int i = 0; i < l.Count; i++)
                if (l[i].Id == c.Id)
                {

                }*/
        }
        public void Delete(MFuncionario c)
        {
            List<MFuncionario> l = Select();
            IEnumerable<MFuncionario> lcont = l.Where(x => x.Id == c.Id);
            if (lcont.Count() > 0)
            {
                l.Remove(lcont.First());
                Salvar(l);
            }
        }
    }
}
