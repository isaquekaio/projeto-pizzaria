﻿using Modelo;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Persistencia
{
    class PItem
    {
        private string arquivo = "c:\\temp\\item.xml";
        private List<MItem> Abrir()
        {
            XmlSerializer xml = new XmlSerializer(typeof(List<MItem>));
            StreamReader f = new StreamReader(arquivo, Encoding.Default);
            List<MItem> l = (List<MItem>)xml.Deserialize(f);
            f.Close();
            return l;
        }
        private void Salvar(List<MItem> l)
        {
            XmlSerializer xml = new XmlSerializer(typeof(List<MItem>));
            StreamWriter f = new StreamWriter(arquivo, false, Encoding.Default);
            xml.Serialize(f, l);
            f.Close();
        }
        public List<MItem> Select()
        {
            try
            {
                return Abrir();
            }
            catch
            {
            }
            return new List<MItem>();
        }
        public void Insert(MItem c)
        {
            List<MItem> l = null;
            try
            {
                l = Abrir();
            }
            catch
            {
                l = new List<MItem>();
            }
            l.Add(c);
            Salvar(l);
        }
        public void Update(MItem c)
        {
            List<MItem> l = Select();
            IEnumerable<MItem> lcont = l.Where(x => x.Id == c.Id);
            if (lcont.Count() > 0)
            {
                MItem lc = lcont.First();
                lc.Id = c.Id;
                lc.Nome = c.Nome;
                lc.Descricao = c.Descricao;
                lc.Preco = c.Preco;

                Salvar(l);
            }
            /*for (int i = 0; i < l.Count; i++)
                if (l[i].Id == c.Id)
                {

                }*/
        }
        public void Delete(MItem c)
        {
            List<MItem> l = Select();
            IEnumerable<MItem> lcont = l.Where(x => x.Id == c.Id);
            if (lcont.Count() > 0)
            {
                l.Remove(lcont.First());
                Salvar(l);
            }
        }
    }
}
