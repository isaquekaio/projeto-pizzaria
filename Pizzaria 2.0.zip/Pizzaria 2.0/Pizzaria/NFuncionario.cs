﻿using Modelo;
using Persistencia;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Negocio
{
    class NFuncionario
    {
        public List<MFuncionario> Select()
        {
            PFuncionario p = new PFuncionario();
            return p.Select();
        }
        public void Insert(MFuncionario c)
        {
            // Validação do Nome
            if (c.Nome == "") throw new ArgumentOutOfRangeException();
            // Validação do Id
            PFuncionario p = new PFuncionario();
            List<MFuncionario> l = p.Select();
            if (l.Where(x => x.Id == c.Id).Count() > 0)
                throw new ArgumentOutOfRangeException(); 
            p.Insert(c);
        }
        public void Update(MFuncionario c)
        {
            // Validação
            if (c.Nome == "") throw new ArgumentOutOfRangeException();
            PFuncionario p = new PFuncionario();
            p.Update(c);
        }
        public void Delete(MFuncionario c)
        {
            PFuncionario p = new PFuncionario();
            p.Delete(c);
        }
    }
}
